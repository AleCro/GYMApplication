import{a as r}from"../chunks/P8b-s9jE.js";import{x as t}from"../chunks/DvDWJgkm.js";export{t as load_css,r as start};
