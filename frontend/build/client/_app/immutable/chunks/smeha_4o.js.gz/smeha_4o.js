const s=globalThis.__sveltekit_hgleot?.base??"",e=globalThis.__sveltekit_hgleot?.assets??s??"";export{e as a,s as b};
