function u(n){return--n*n*n*n*n+1}export{u as q};
