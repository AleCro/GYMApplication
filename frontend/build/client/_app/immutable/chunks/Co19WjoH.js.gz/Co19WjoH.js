import{s,h as e,x as n}from"./DFFLsmBn.js";function u(t){var r=n(0);return function(){return arguments.length===1?(s(r,e(r)+1),arguments[0]):(e(r),t())}}export{u as r};
